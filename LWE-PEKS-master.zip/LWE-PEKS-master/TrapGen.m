function [A,S]=TrapGen(n,m,q)
A=round((q-1)*rand(n,m));
B=zeros(n,m);
for i=1:m
    B(:,i)=A(:,m-i+1);
end
D=uptri(B,q);
E=SF(D,q);
for i=1:m
    T(i,:)=E(m-i+1,:);
end
P=T;
for j=1:m-n
    P(:,j)=T(:,m-n-j+1);
end
Q=q*eye(n,n);
O=zeros(m-n,n);
T=[O;Q];
S=[P,T];
end

% function shortestVector = SF(matrix, constant)
%     [~, n] = size(matrix); % 获取矩阵的行数和列数
%     shortestVector = []; % 初始化最短向量数组
% 
%     for i = 1:n
%         basis = latticeBasis(matrix, i); % 计算子基
%         B = basis' * basis; % 计算子基的基格
%         [~, R] = qr(B); % 对基格进行QR分解
%         U = R \ basis'; % 计算子基的上三角
%         v = U(i, 1:i-1); % 提取第 i 行的向量
%         t = (constant * v)'; % 乘以常数
% 
%         % 找到向量中模长最小的元素
%         if isempty(shortestVector) || norm(t) < norm(shortestVector)
%             shortestVector = t;
%         end
%     end
% end
% 
% function basis = latticeBasis(matrix, index)
%     [~, n] = size(matrix); % 获取矩阵的行数和列数
%     basis = zeros(n, n);
% 
%     for i = 1:n
%         for j = 1:n
%             % 把矩阵中的元素复制到基矩阵中的对应位置
%             basis(i, j) = matrix(index(i), j);
%         end
%     end
% end

function shortestVector = SF(matrix, constant)
    [~, n] = size(matrix); % 获取矩阵的行数和列数
    shortestVector = []; % 初始化最短向量数组

    for i = 1:n
        if i <= size(matrix, 1) % 添加索引范围的检查
            basis = latticeBasis(matrix, i); % 计算子基
            B = basis' * basis; % 计算子基的基格
            [~, R] = qr(B); % 对基格进行QR分解
            U = R \ basis'; % 计算子基的上三角
            v = U(i, 1:i-1); % 提取第 i 行的向量
            t = (constant * v)'; % 乘以常数

            % 找到向量中模长最小的元素
            if isempty(shortestVector) || norm(t) < norm(shortestVector)
                shortestVector = t;
            end
        end
    end
end

function basis = latticeBasis(matrix, index)
    [~, n] = size(matrix); % 获取矩阵的行数和列数
    basis = zeros(n, n);

    for i = 1:n
        for j = 1:n
            % 把矩阵中的元素复制到基矩阵中的对应位置
            % 确保index(i)不超过matrix的行数
            basis(i, j) = matrix(min(index(i), size(matrix, 1)), j);
        end
    end
end

% function [A,R]=TrapGen(n,k,q)
% m1=n;
% w=n*k;
% A0=randi([0,q-1],n,m1);
% r=randi([0,q-1],1,k);
% for i=1:n
%     R(i,k*(i-1)+1:k*i)=r;
% end
% H=eye(n,n);
% G=PrimG(n,k,q);
% A1=H*G-A0*R;
% A=mod([A0,A1],q);
% end

% function G=PrimG(n,k,q)
% G=zeros(n,n*k);
% for i=1:k
%     g(i)=mod(2^(i-1),q);
% end
% for i=1:n
%     G(i,k*(i-1)+1:k*i)=g;
% end
% end

% function [A,R]=TrapGen(n,k,q)
% m1 = n;
% w = n*k;
% A0 = randi([0,q-1],n,m1);
% r = randi([0,q-1],1,k);
% R = zeros(n, n);  % 创建一个全零的 n x n 方阵 R
% for i = 1:n
%     R(i, (k*(i-1)+1):(k*i)) = r;
% end
% H=eye(n,n);
% G=PrimG(n,k,q);
% A1=H*G-A0*R;
% A=mod([A0,A1],q);
% end
% 
% function G=PrimG(n,k,q)
% G=zeros(n,n*k);
% for i=1:k
%     g(i)=mod(2^(i-1),q);
% end
% for i=1:n
%     G(i,k*(i-1)+1:k*i)=g;
% end
% end

% function [A,R]=TrapGen(n,k,q)
% m1=n;
% w=n*k;
% A0=randi([0,q-1],n,m1);
% r=randi([0,q-1],1,k);
% for i=1:n
% R(i,k*(i-1)+1:k*i)=r;
% end
% H=eye(n,n);
% G=PrimG(n,k,q);
% A1=H*G-A0*R;
% A=mod([A0,A1],q);
% end
% function G=PrimG(n,k,q)
% G=zeros(n,n*k);
% for i=1:k
% g(i)=mod(2^(i-1),q);
% end
% for i=1:n
% G(i,k*(i-1)+1:k*i)=g;
% end
% end